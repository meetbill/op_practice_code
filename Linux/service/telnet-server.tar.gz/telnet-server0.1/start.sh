#!/bin/bash
g_CUR_DIR=`pwd`
g_DIR_UPDATE=${g_CUR_DIR}/telnet-server/
g_IsContinue='y'

function InstallTelnet()
{
	cd ${g_DIR_UPDATE}
	#安装telnet
	rpm -ivh xinetd-2.3.14-39.el6_4.x86_64.rpm
	rpm -ivh telnet-server-0.17-48.el6.x86_64.rpm
	
	#配置telnet
	sed -i "s/yes/no/g" /etc/xinetd.d/telnet
	sed -i "s/log_on_failure/#log_on_failure/g" /etc/xinetd.d/telnet
	
	#设置为可以使用root登陆telnet
    if [[ -f /etc/securetty ]]
    then
	    mv /etc/securetty /etc/securetty.bak
    fi
	
	#重启telnet
	service xinetd restart
	
	#检查telnet是否启动
	local CK_TELNET
	CK_TELNET=`netstat -tunlp| grep :23 | grep xinetd | wc -l`
	if [[ ${CK_TELNET} != 0 ]]; 
	then
		echo "telnet install end!" 
	else
		read -p 'continue?[y/n]' g_IsContinue
		if [[ ${g_IsContinue} == 'n' ]]
		then 
			exit 0
		fi
	fi

}

function Telnet()
{
	mv /etc/securetty.bak /etc/securetty
    /etc/init.d/xinetd stop
    chkconfig xinetd off
}
#{{{main
function main()
{   
	#开始安装
	#清空yum 安装一些所需
	OPTION=$(whiptail --title "telnet server manager" --menu "Choose your option" 15 60 3\
	"1" "Install & start telnet server" \
	"2" "stop telnet server" \
	"3" "Exit" 3>&1 1>&2 2>&3)
	  
	exitstatus=$?
	if [ $exitstatus = 0 ]; then
		if [ $OPTION = 1 ]; then
			InstallTelnet
		elif [ $OPTION = 2 ]; then
            Telnet
		elif [ $OPTION = 3 ]; then
			echo "Exit Script" && exit 1
		fi
	else
		echo "You chose Cancel."
	fi
}
#}}}
main
