#!/bin/bash
#########################################################################
# File Name: start.sh
# Author: meetbill
# mail: meetbill@163.com
# Created Time: 2017-06-22 05:39:00
#########################################################################

cp tools/uwsgi /usr/bin/
chmod +x /usr/bin/uwsgi

cp tools/uwsgid.service /etc/init.d/
chmod /etc/init.d/uwsgid.service
