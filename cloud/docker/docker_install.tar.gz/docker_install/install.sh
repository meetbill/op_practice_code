#!/bin/bash
#########################################################################
# File Name: install.sh
# Author: meetbill
# mail: meetbill@163.com
# Created Time: 2017-06-13 22:35:36
#########################################################################

## docker-ce1703

if [ -d /etc/yum.repos.d/bak  ]; then
    /bin/rm -rf /etc/yum.repos.d/bak
fi
mkdir /etc/yum.repos.d/bak
mv /etc/yum.repos.d/*.repo /etc/yum.repos.d/bak/


tar -zxf ./docker_file.tar.gz -C /tmp/

echo "
[docker_local]
Name=docker_local 
baseurl=file:///tmp/docker_file/
enable=1
gpgcheck=0
" > /etc/yum.repos.d/docker_local.repo


yum -y install docker-ce

/bin/rm /etc/yum.repos.d/docker_local.repo

mv /etc/yum.repos.d/bak/*.repo /etc/yum.repos.d/

[[ -d "/tmp/docker_file/" ]] && /bin/rm -rf /tmp/docker_file/

systemctl enable docker.service
